# Keras Colab #

This directory contains an example of using the experimental Cloud TPU-Keras
integration that was added in TF 1.9 in an interactive collaboratory
environment. To learn more about this new integration,
check out the documentation (coming soon!).
