Tensor2Tensor: See https://github.com/tensorflow/tensor2tensor/blob/master/docs/cloud_tpu.md

BERT: See https://github.com/google-research/bert/blob/master/README.md
